/**
 * Selecting All elements we want to have a reveal animation
 */
const revealEls = document.querySelectorAll('section[data-reveal="true"]')


/**
 * Initialize Reveal Animation if Element is visible to page screen
 */
const AnimateReveal = () => {
    revealEls.forEach(el => {
        /**
         * Check if the element height for at least 50% visible to page screen then add the reveal class if not existing yet
         * else: Remove the reveal class name if it exists
         */
        if((el.getBoundingClientRect().top + (el.clientHeight * .5)) < window.innerHeight)  {
            if(!el.classList.contains('reveal'))
                el.classList.add('reveal')
        }else{

            if(el.classList.contains('reveal'))
                el.classList.remove('reveal')
        }
    });
}

/** Trigger Animation on page load */
window.onload = function(){
    AnimateReveal();
}
/** Trigger Animation on scroll */
window.onscroll = function(){
    AnimateReveal();
}